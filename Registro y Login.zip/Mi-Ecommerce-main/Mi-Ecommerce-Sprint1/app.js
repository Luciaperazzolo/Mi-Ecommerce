//--- IMPORTACIÓN DE MÓDULOS ---
const express = require ('express'); //Traigo la Heramienta
const app = express (); //La pongo en función

//--- CONFIGURACIÓN DEL SERVIDOR ---
app.set ('view engine', 'ejs');
app.use(express.static(__dirname +'/assets'));

//--- DEFINICIÓN DE RUTAS (USER STORY #2) ---
app.get ('/', (req, res) => {res.render("pages/index");
});

app.get ('/cart', (req, res) => {res.render ('pages/cart');
});

//Acá abajo deberiamos definir las rutas que faltan.

//--- REGISTRO - LOGIN (USER STORY #3)/(USER STORY #4)
app.get('/', (req, res) => {
    res.render('pages/index');
});

app.get('/login', (req, res) => {
    res.render('pages/login');
});

app.get('/register', (req, res) => {
    res.render('pages/register');
});

//--- PUESTA EN MARCHA ---
app.listen(3000, () => { //Encender servidor
    console.log("Servidor corriendo en http://localhost:3000"); //mje en terminal: "Servidor funcionando en: http://localhost:3000"
});

